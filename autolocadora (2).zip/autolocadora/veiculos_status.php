<?php
include 'conexao.php';

$sql = "SELECT veiculo_placa, veiculo_marca, veiculo_descricao, veiculo_status FROM tbveiculo";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Status dos Veículos</title>
</head>
<body>
    <h1>Veículos - Disponíveis / Locados</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Placa</th>
                <th>Marca</th>
                <th>Descrição</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        <?php
        if ($result->num_rows > 0) {
            while ($v = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($v['veiculo_placa']) . "</td>";
                echo "<td>" . htmlspecialchars($v['veiculo_marca']) . "</td>";
                echo "<td>" . htmlspecialchars($v['veiculo_descricao']) . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>Nenhum veículo encontrado</td></tr>";
        }
        ?>
        </tbody>
    </table>
    <p><a href="index.php">Voltar</a></p>
</body>
</html>
<?php $conn->close(); ?>

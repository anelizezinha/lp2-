<?php 
$conexao = new mysqli("localhost", "root", "", "bdautolocadora");


if ($conexao->connect_errno) {
    echo "Falha ao conectar com o MySQL: " . $conexao->connect_error;
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Veículos</title>
</head>
<body>
    <h2>Cadastro de Veículos</h2>

    <form action="inserirVeiculo.php" method="POST">
        <label>Placa:</label><br>
        <input type="text" name="placa" required><br><br>

        <label>Descrição:</label><br>
        <input type="text" name="descricao" required><br><br>

        <label>Marca:</label><br>
        <select name="marca" required>
            <option value="">Selecione uma marca</option>
            <?php
            $sql = "SELECT * FROM tbmarca";
            $result = $conexao->query($sql);

            while ($row = $result->fetch_assoc()) {
                echo "<option value='{$row['marca_codigo']}'>{$row['marca_descricao']}</option>";
            }
            ?>
        </select><br><br>

        <button type="submit">Cadastrar</button>
    </form>
</body>
</html>

<?php
include 'conexao.php';

$sql = "SELECT veiculo_placa, veiculo_marca, veiculo_descricao FROM tbveiculo";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Veículos</title>
</head>
<body>
    <h1>🚗 Veículos Cadastrados</h1>
    <table border="1">
        <tr>
            <th>Placa</th>
            <th>Marca</th>
            <th>Descrição</th>
        </tr>
        <?php while ($v = $result->fetch_assoc()) : ?>
            <tr>
                <td><?= htmlspecialchars($v['veiculo_placa']) ?></td>
                <td><?= htmlspecialchars($v['veiculo_marca']) ?></td>
                <td><?= htmlspecialchars($v['veiculo_descricao']) ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
    <p><a href="index.php">Voltar</a></p>
</body>
</html>

<?php
include 'conexao.php';

if (!isset($_GET['placa'])) {
    die("Placa do veículo não informada.");
}

$placa = $conn->real_escape_string($_GET['placa']);
$sql = "SELECT * FROM tbveiculo WHERE veiculo_placa = '$placa'";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    die("Veículo não encontrado.");
}

$veiculo = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Detalhes do Veículo</title>
</head>
<body>
    <h1>Detalhes do Veículo</h1>
    <ul>
        <li><strong>Placa:</strong> <?= htmlspecialchars($veiculo['veiculo_placa']) ?></li>
        <li><strong>Marca:</strong> <?= htmlspecialchars($veiculo['veiculo_marca']) ?></li>
        <li><strong>Descrição:</strong> <?= htmlspecialchars($veiculo['veiculo_descricao']) ?></li>
    </ul>
    <p><a href="veiculos.php">Voltar à lista</a></p>
</body>
</html>
<?php $conn->close(); ?>

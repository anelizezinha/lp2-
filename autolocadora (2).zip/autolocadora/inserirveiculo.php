<?php
$conexao = new mysqli("localhost", "root", "", "bdautolocadora");

if ($conexao->connect_errno) {
    echo "Erro ao conectar ao MySQL: " . $conexao->connect_error;
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $placa = $_POST['placa'];
    $descricao = $_POST['descricao'];
    $marca = $_POST['marca'];

    $sql = "INSERT INTO tbveiculo (veiculo_placa, veiculo_marca, veiculo_descricao) VALUES (?, ?, ?)";
    $stmt = $conexao->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("sis", $placa, $marca, $descricao);
        if ($stmt->execute()) {
            echo "Veículo cadastrado com sucesso!";
        } else {
            echo "Erro ao cadastrar: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Erro na consulta SQL: " . $conexao->error;
    }
}
$conexao->close();
?>

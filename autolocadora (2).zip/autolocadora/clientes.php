<?php
include 'conexao.php';

$sql = "SELECT idcliente, nome, telefone, cnh FROM tbcliente";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Lista de Clientes</title>
</head>
<body>
    <h1>Clientes Cadastrados</h1>
    <table border="1" cellpadding="5" cellspacing="0">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Telefone</th>
                <th>CNH</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($cliente = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $cliente['idcliente'] . "</td>";
                    echo "<td>" . htmlspecialchars($cliente['nome']) . "</td>";
                    echo "<td>" . htmlspecialchars($cliente['telefone']) . "</td>";
                    echo "<td>" . htmlspecialchars($cliente['cnh']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>Nenhum cliente encontrado.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>

<?php
$conn->close();
?>

<?php
include 'conexao.php';

$sql = "SELECT idmarca, descricao FROM tbmarca";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Lista de Marcas</title>
</head>
<body>
    <h1>Marcas de Veículos</h1>
    <table border="1" cellpadding="5" cellspacing="0">
        <thead>
            <tr>
                <th>ID</th>
                <th>Marca</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($marca = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $marca['idmarca'] . "</td>";
                    echo "<td>" . htmlspecialchars($marca['descricao']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='2'>Nenhuma marca encontrada.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>

<?php
$conn->close();
?>

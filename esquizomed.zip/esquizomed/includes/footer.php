</main>
<footer>
    <p>&copy; 2025 ESQUIZOMED - Sistema de Controle de Medicamentos</p>
</footer>
</body>
</html>

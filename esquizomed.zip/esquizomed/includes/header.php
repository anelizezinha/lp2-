<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>ESQUIZOMED</title>
    <link rel="stylesheet" href="/esquizomed/css/estilo.css">
</head>
<body>
<header>
    <h1>ESQUIZOMED</h1>
    <nav>
        <ul>
            <li><a href="/esquizomed/index.php">Início</a></li>
            <li><a href="/esquizomed/usuarios/cadastro.php">Cadastro de Usuário</a></li>
            <li><a href="/esquizomed/medicamentos/cadastro.php">Cadastro de Medicamento</a></li>
            <li><a href="/esquizomed/busca/filtro.php">Buscar Medicamentos</a></li>
            <li><a href="/esquizomed/login.php">Login</a></li>
            <li><a href="/esquizomed/logout.php">Sair</a></li>
        </ul>
    </nav>
</header>
<main>

<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit;
}
?>

<?php include("../includes/conexao.php"); ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Usuário</title>
    <link rel="stylesheet" href="../css/estilo.css">
    <script src="../js/interacoes.js"></script>
</head>
<body>
    <h2>Cadastro de Usuário</h2>
    <form method="post" onsubmit="return validarUsuario()">
        <input type="text" name="nome" id="nome" placeholder="Nome" required><br>
        <input type="email" name="email" id="email" placeholder="Email" required><br>
        <input type="password" name="senha" id="senha" placeholder="Senha" required><br>
        <input type="submit" value="Cadastrar">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $senha = $_POST['senha'];

        $senhaSegura = password_hash($senha, PASSWORD_DEFAULT);

        $sql = "INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('sss', $nome, $email, $senhaSegura);

        if ($stmt->execute()) {
            echo "<p style='color:green;'>Usuário cadastrado com sucesso!</p>";
        } else {
            echo "<p style='color:red;'>Erro ao cadastrar: " . $stmt->error . "</p>";
        }
    }
    ?>
</body>
</html>


function validarUsuario() {
    let nome = document.getElementById("nome").value;
    let email = document.getElementById("email").value;
    let senha = document.getElementById("senha").value;

    if (nome === "" || email === "" || senha === "") {
        alert("Preencha todos os campos!");
        return false;
    }

    if (senha.length < 6) {
        alert("A senha deve ter pelo menos 6 caracteres.");
        return false;
    }

    return true;
}

function validarMedicamento() {
    let nome = document.getElementById("nomeMed").value;
    let tipo = document.getElementById("tipo").value;
    let quantidade = document.getElementById("quantidade").value;
    let data = document.getElementById("data_entrada").value;

    if (nome === "" || tipo === "" || quantidade === "" || data === "") {
        alert("Todos os campos devem ser preenchidos!");
        return false;
    }

    if (quantidade <= 0) {
        alert("A quantidade deve ser maior que zero.");
        return false;
    }

    return true;
}

function validarContato() {
    let nome = document.getElementById("nomeContato").value;
    let email = document.getElementById("emailContato").value;
    let mensagem = document.getElementById("mensagem").value;

    if (nome === "" || email === "" || mensagem === "") {
        alert("Por favor, preencha todos os campos.");
        return false;
    }

    return true;
}


CREATE DATABASE IF NOT EXISTS esquizomed;
USE esquizomed;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    email VARCHAR(100),
    senha VARCHAR(100)
);

CREATE TABLE medicamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    tipo VARCHAR(50),
    quantidade INT,
    data_entrada DATE
);

INSERT INTO usuarios (nome, email, senha) VALUES
('Anelize Pinheiro', 'anelize@email.com', '123456');

INSERT INTO medicamentos (nome, tipo, quantidade, data_entrada) VALUES
('Dipirona', 'Analgésico', 100, CURDATE());

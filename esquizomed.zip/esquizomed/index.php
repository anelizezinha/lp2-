<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>ESQUIZOMED</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <h1>Bem-vindo ao ESQUIZOMED</h1>
    <nav>
        <ul>
            <li><a href="usuarios/cadastro.php">Cadastro de Usuário</a></li>
            <li><a href="medicamentos/cadastro.php">Cadastro de Medicamento</a></li>
            <li><a href="busca/filtro.php">Buscar Medicamentos</a></li>
        </ul>
    </nav>
</body>
</html>

<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: /esquizomed/login.php");
    exit;
}
?>

<?php include("../includes/conexao.php"); ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Busca de Medicamentos</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body>
    <h2>Buscar Medicamentos por Tipo</h2>
    <form method="get">
        <input type="text" name="filtro" placeholder="Digite o tipo do medicamento">
        <input type="submit" value="Buscar">
    </form>
    <?php
    if (isset($_GET['filtro'])) {
        $filtro = $_GET['filtro'];
        $sql = "SELECT * FROM medicamentos WHERE tipo LIKE '%$filtro%'";
        $resultado = $conn->query($sql);
        if ($resultado->num_rows > 0) {
            echo "<table><tr><th>Nome</th><th>Tipo</th><th>Quantidade</th><th>Data de Entrada</th></tr>";
            while ($linha = $resultado->fetch_assoc()) {
                echo "<tr><td>{$linha['nome']}</td><td>{$linha['tipo']}</td><td>{$linha['quantidade']}</td><td>{$linha['data_entrada']}</td></tr>";
            }
            echo "</table>";
        } else {
            echo "Nenhum medicamento encontrado com esse filtro.";
        }
    }
    ?>
</body>
</html>

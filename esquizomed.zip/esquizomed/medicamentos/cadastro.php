<?php include("../includes/conexao.php"); ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Medicamento</title>
    <link rel="stylesheet" href="../css/estilo.css">
    <script src="../js/interacoes.js"></script>
</head>
<body>
    <h2>Cadastro de Medicamento</h2>
    <form method="post" onsubmit="return validarMedicamento()">
        <input type="text" name="nome" id="nomeMed" placeholder="Nome do Medicamento"><br>
        <input type="text" name="tipo" id="tipo" placeholder="Tipo"><br>
        <input type="number" name="quantidade" id="quantidade" placeholder="Quantidade"><br>
        <input type="date" name="data_entrada" id="data_entrada"><br>
        <input type="submit" value="Cadastrar">
    </form>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nome = $_POST['nome'];
        $tipo = $_POST['tipo'];
        $quantidade = $_POST['quantidade'];
        $data_entrada = $_POST['data_entrada'];
        $sql = "INSERT INTO medicamentos (nome, tipo, quantidade, data_entrada) VALUES ('$nome', '$tipo', $quantidade, '$data_entrada')";
        if ($conn->query($sql) === TRUE) {
            echo "Medicamento cadastrado com sucesso!";
        } else {
            echo "Erro: " . $conn->error;
        }
    }
    ?>
</body>
</html>
